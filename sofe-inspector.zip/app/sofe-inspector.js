chrome.devtools.panels.create(
	"SofeInspector",
	"badge.png",
	"sofe-inspector.html",
	function cb(panel) {}
);
